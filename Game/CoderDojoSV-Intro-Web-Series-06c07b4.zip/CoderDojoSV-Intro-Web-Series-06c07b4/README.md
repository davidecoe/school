#Introduction to Web Site Programming

*3 days of HTML, CSS, and JavaScript fun!* presented as a workshop for beginners by CoderDojo Silicon Valley

##Description

All websites are a combination of code in 3 languages: HTML, CSS, and JavaScript. We will take a 3 day tour of how they work and create some fun projects!

[:rocket: Day 1 - HTML and CSS - Share Your Favorite Book or Summer Activity](http://rawgit.com/CoderDojoSV/Intro-Web-Series/master/Day%201/index.html)

[:rocket: Day 2 - More HTML and CSS - Let's Make a Maze!](Day 2/)

[:rocket: Day 3 - A quick intro to JavaScript - Add cool effects to your site](Day 3/)

