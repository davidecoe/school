#Day 1: HTML and CSS

Here are today's materials: http://rawgit.com/CoderDojoSV/Intro-Web-Series/master/Day%201/index.html


