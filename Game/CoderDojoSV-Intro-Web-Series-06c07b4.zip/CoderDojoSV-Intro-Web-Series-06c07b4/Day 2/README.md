#Day 2: Let's Make a Maze!


Here are today's materials: https://rawgit.com/CoderDojoSV/Intro-Web-Series/master/Day%202/index.html
